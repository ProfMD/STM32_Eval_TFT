
#ifndef _SDIOF1_H_
#define _SDIOF1_H_

#include <SdFat.h>

#endif
